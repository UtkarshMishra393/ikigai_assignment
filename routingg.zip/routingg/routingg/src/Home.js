const Home = () => {
  return (
    <div className="container mt-5">
      <h2>Welcome to the Home Page</h2>
      <p>This is the home page of the React Routing Example.</p>
      <p style={{fontSize: "300px"}}><b>Home</b></p>
    </div>
  );
};

export default Home;
