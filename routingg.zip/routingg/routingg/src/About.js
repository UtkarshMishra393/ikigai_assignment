const About = () => {
  return (
    <div className="container mt-5">
      <h2>About Us</h2>
      <p>This is the About Us page of the React Routing Example.</p>
      <p style={{fontSize: "300px"}}><b>About</b></p>
    </div>
  );
};

export default About;
